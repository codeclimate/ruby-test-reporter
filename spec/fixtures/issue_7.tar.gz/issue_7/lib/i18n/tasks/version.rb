# frozen_string_literal: true
module I18n
  module Tasks
    VERSION = '0.9.8'
  end
end
